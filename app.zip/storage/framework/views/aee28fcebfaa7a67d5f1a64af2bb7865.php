<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', 'SIMRS'); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="bg-gray-50 min-h-screen">

<nav class="bg-white border-b border-gray-200 px-6 py-3 flex items-center gap-6">
    <span class="font-semibold text-teal-700 text-lg">SIMRS</span>
    <a href="<?php echo e(route('kunjungan.index')); ?>"
       class="text-sm <?php echo e(request()->routeIs('pasien.*') ? 'text-teal-700 font-medium' : 'text-gray-500 hover:text-gray-700'); ?>">
        Data Kunjungan
    </a>
</nav>

<main class="max-w-7xl mx-auto px-6 py-8">

    <?php if(session('success')): ?>
        <div
            class="mb-5 px-4 py-3 bg-teal-50 border border-teal-200 text-teal-800 rounded-lg text-sm flex items-center gap-2">
            <svg class="w-4 h-4 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
            </svg>
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div
            class="mb-5 px-4 py-3 bg-red-50 border border-red-200 text-red-800 rounded-lg text-sm flex items-center gap-2">
            <svg class="w-4 h-4 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
            </svg>
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    <?php echo $__env->yieldContent('content'); ?>

</main>

</body>
</html>
<?php /**PATH C:\Users\firma\Documents\rsib-tech-test\resources\views/layouts/app.blade.php ENDPATH**/ ?>