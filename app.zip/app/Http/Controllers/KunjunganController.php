<?php

namespace App\Http\Controllers;

use App\Http\Requests\PatientRequest;
use App\Models\Kunjungan;
use App\Models\Pasien;
use Illuminate\Http\RedirectResponse;
use Illuminate\View\View;

class KunjunganController extends Controller
{
    public function index(): View
    {
        $pasien = Pasien::query()
            ->orderBy('nama_pasien')
            ->paginate(15);
        return view('kunjungan.index', compact('pasien'));
    }

    public function create(): View
    {
        return view('kunjungan.create');
    }

    public function store(PatientRequest $request): RedirectResponse
    {
        $pasien = Pasien::create($request->validated());

        // kunjungan pertama
        $pasien->kunjungan()->create($request->only([
            'tanggal_kunjungan',
            'poli_tujuan',
            'dokter',
            'jenis_pembayaran',
        ]));


        return redirect()
            ->route('kunjungan.index')
            ->with('success', 'Data pasien berhasil ditambahkan.');
    }

    public function edit(Pasien $pasien): View
    {
        return view('kunjungan.edit', compact('pasien'));
    }

    public function update(PatientRequest $request, Pasien $pasien): RedirectResponse
    {
        $pasien->update($request->validated());
        return redirect()
            ->route('kunjungan.index')
            ->with('success', 'Data pasien berhasil diperbarui.');
    }

    public function destroy(Kunjungan $kunjungan): RedirectResponse
    {
        $kunjungan->update([
            'status' => 'batal'
        ]);

        return redirect()
            ->route('kunjungan.index')
            ->with('success', 'Kunjungan pasien berhasil dibatalkan.');
    }
}
