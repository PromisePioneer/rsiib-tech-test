@extends('layouts.app')

@section('title', 'Daftar Pasien')

@section('content')

    <div class="flex items-center justify-between mb-6">
        <div>
            <h1 class="text-xl font-semibold">Daftar Pasien</h1>
            <p class="text-sm text-gray-500 mt-0.5">Total {{ $pasien->total() }} pasien terdaftar</p>
        </div>
        <a href="{{ route('kunjungan.create') }}"
           class="inline-flex items-center gap-2 bg-teal-600 hover:bg-teal-700 text-white text-sm px-4 py-2 rounded-lg transition">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/>
            </svg>
            Daftar Pasien Baru
        </a>
    </div>

    {{-- Filter --}}
    <form method="GET" action="{{ route('kunjungan.index') }}" class="flex gap-3 mb-5 flex-wrap">
        <div class="relative flex-1 min-w-[200px]">
            <svg class="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" fill="none"
                 stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                      d="M21 21l-4.35-4.35M17 11A6 6 0 1 1 5 11a6 6 0 0 1 12 0z"/>
            </svg>
            <input type="text" name="search" value="{{ request('search') }}"
                   placeholder="Cari nama atau no. HP..."
                   class="w-full pl-9 pr-4 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500">
        </div>
        <button type="submit"
                class="text-sm px-4 py-2 border border-gray-200 rounded-lg hover:bg-gray-100 transition">
            Cari
        </button>
        @if(request()->anyFilled(['search', 'jenis_kelamin']))
            <a href="{{ route('kunjungan.index') }}"
               class="text-sm px-4 py-2 border border-gray-200 rounded-lg hover:bg-gray-100 transition text-gray-500">
                Reset
            </a>
        @endif
    </form>

    {{-- Tabel --}}
    <div class="bg-white border border-gray-200 rounded-xl overflow-x-auto">
        <table class="w-full text-sm">
            <thead>
            <tr class="border-b border-gray-100">
                <th class="text-left px-4 py-3 text-gray-400 font-medium text-xs w-10">#</th>
                <th class="text-left px-4 py-3 text-gray-400 font-medium text-xs">Nama Pasien</th>
                <th class="text-left px-4 py-3 text-gray-400 font-medium text-xs">Tgl. Lahir</th>
                <th class="text-left px-4 py-3 text-gray-400 font-medium text-xs">Kelamin</th>
                <th class="text-left px-4 py-3 text-gray-400 font-medium text-xs">No. HP</th>
                <th class="text-left px-4 py-3 text-gray-400 font-medium text-xs">Kunjungan Terakhir</th>
                <th class="text-left px-4 py-3 text-gray-400 font-medium text-xs">Poli</th>
                <th class="text-left px-4 py-3 text-gray-400 font-medium text-xs">Dokter</th>
                <th class="text-left px-4 py-3 text-gray-400 font-medium text-xs">Pembayaran</th>
                <th class="text-right px-4 py-3 text-gray-400 font-medium text-xs">Aksi</th>
            </tr>
            </thead>
            <tbody class="divide-y divide-gray-50">
            @forelse($pasien as $index => $p)
                @php $k = $p->kunjungan->last(); @endphp
                <tr class="hover:bg-gray-50 transition">
                    <td class="px-4 py-3 text-gray-400 text-xs">
                        {{ $pasien->firstItem() + $index }}
                    </td>
                    <td class="px-4 py-3">
                        <div class="flex items-center gap-2.5">
                            <div
                                class="w-8 h-8 rounded-full bg-teal-100 text-teal-700 flex items-center justify-center text-xs font-medium shrink-0">
                                {{ strtoupper(substr($p->nama_pasien, 0, 1)) }}{{ strtoupper(substr(strstr($p->nama_pasien.' ', ' '), 1, 1)) }}
                            </div>
                            <div>
                                <div class="font-medium text-gray-800">{{ $p->nama_pasien }}</div>
                                <div class="text-xs text-gray-400 truncate max-w-[160px]">{{ $p->alamat }}</div>
                            </div>
                        </div>
                    </td>
                    <td class="px-4 py-3 text-gray-600 text-xs whitespace-nowrap">
                        {{ $p->tanggal_lahir->format('d M Y') }}
                        <div class="text-gray-400">{{ $p->umur }} thn</div>
                    </td>
                    <td class="px-4 py-3">
                        @if($p->jenis_kelamin === 'Laki-laki')
                            <span class="inline-block px-2 py-0.5 rounded-full text-xs bg-blue-50 text-blue-700">Laki-laki</span>
                        @else
                            <span class="inline-block px-2 py-0.5 rounded-full text-xs bg-pink-50 text-pink-700">Perempuan</span>
                        @endif
                    </td>
                    <td class="px-4 py-3 text-gray-600 text-xs">{{ $p->no_hp }}</td>
                    <td class="px-4 py-3 text-gray-600 text-xs whitespace-nowrap">
                        {{ $k ? $k->tanggal_kunjungan->format('d M Y') : '-' }}
                    </td>
                    <td class="px-4 py-3 text-xs">
                        @if($k)
                            @if($k->status === 'batal')
                                <span class="line-through text-gray-400">{{ $k->poli_tujuan }}</span>
                            @else
                                {{ $k->poli_tujuan }}
                            @endif
                        @else
                            <span class="text-gray-400">-</span>
                        @endif
                    </td>
                    <td class="px-4 py-3 text-xs text-gray-600">
                        {{ $k?->dokter ?? '-' }}
                    </td>
                    <td class="px-4 py-3">
                        @if($k)
                            @if($k->status === 'batal')
                                <span
                                    class="inline-block px-2 py-0.5 rounded-full text-xs bg-red-50 text-red-700">Batal</span>
                            @else
                                @php
                                    $colors = ['BPJS'=>'bg-green-50 text-green-700','Umum'=>'bg-gray-100 text-gray-600','Asuransi'=>'bg-amber-50 text-amber-700','Gratis'=>'bg-teal-50 text-teal-700'];
                                    $cls = $colors[$k->jenis_pembayaran] ?? 'bg-gray-100 text-gray-600';
                                @endphp
                                <span
                                    class="inline-block px-2 py-0.5 rounded-full text-xs {{ $cls }}">{{ $k->jenis_pembayaran }}</span>
                            @endif
                        @else
                            <span class="text-gray-400 text-xs">-</span>
                        @endif
                    </td>
                    <td class="px-4 py-3 text-right">
                        <div class="flex items-center justify-end gap-1.5">
                            <a href="{{ route('kunjungan.edit', $p) }}"
                               class="inline-flex items-center gap-1 text-xs border border-gray-200 px-2.5 py-1.5 rounded-lg hover:bg-gray-100 transition"
                               title="Edit pasien">
                                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                          d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/>
                                </svg>
                                Edit
                            </a>
                            @if($k && $k->status !== 'batal')

                                <form action="{{ route('kunjungan.destroy', $k->id) }}" method="POST"
                                      onsubmit="return confirm('Batalkan kunjungan {{ $p->nama_pasien }}?')">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit"
                                            class="inline-flex items-center gap-1 text-xs border border-red-100 text-red-600 px-2.5 py-1.5 rounded-lg hover:bg-red-50 transition"
                                            title="Batal kunjungan">
                                        <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                  d="M6 18L18 6M6 6l12 12"/>
                                        </svg>
                                        Batal
                                    </button>
                                </form>
                            @endif
                        </div>
                    </td>
                </tr>
            @empty
                <tr>
                    <td colspan="10" class="px-4 py-14 text-center text-gray-400">
                        <svg class="w-10 h-10 mx-auto mb-2 text-gray-300" fill="none" stroke="currentColor"
                             viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"
                                  d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/>
                        </svg>
                        Belum ada data pasien.
                    </td>
                </tr>
            @endforelse
            </tbody>
        </table>
    </div>

    @if($pasien->hasPages())
        <div class="mt-4 flex items-center justify-between text-sm text-gray-500">
            <span>Menampilkan {{ $pasien->firstItem() }}–{{ $pasien->lastItem() }} dari {{ $pasien->total() }} pasien</span>
            {{ $pasien->withQueryString()->links() }}
        </div>
    @endif

@endsection
