@extends('layouts.app')

@section('title', 'Pendaftaran Pasien')

@section('content')

    <div class="max-w-3xl">

        <div class="flex items-center gap-3 mb-6">
            <a href="{{ route('kunjungan.index') }}" class="text-gray-400 hover:text-gray-600 transition">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
                </svg>
            </a>
            <div>
                <h1 class="text-xl font-semibold">Pendaftaran Pasien</h1>
                <p class="text-sm text-gray-500 mt-0.5">Isi data pasien dan kunjungan</p>
            </div>
        </div>

        <form action="{{ route('kunjungan.store') }}" method="POST" class="space-y-5">
            @csrf

            {{-- Data Pasien --}}
            <div class="bg-white border border-gray-200 rounded-xl p-6">
                <p class="text-xs font-medium text-gray-400 uppercase tracking-wide mb-5">
                    <svg class="w-3.5 h-3.5 inline-block mr-1.5 -mt-0.5" fill="none" stroke="currentColor"
                         viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                              d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/>
                    </svg>
                    Data Pasien
                </p>

                <div class="space-y-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1.5">
                            Nama Pasien <span class="text-red-500">*</span>
                        </label>
                        <input type="text" name="nama_pasien" value="{{ old('nama_pasien') }}"
                               placeholder="Nama lengkap sesuai KTP"
                               class="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-teal-500 @error('nama_pasien') border-red-300 bg-red-50 @enderror">
                        @error('nama_pasien')
                        <p class="mt-1 text-xs text-red-600">{{ $message }}</p>
                        @enderror
                    </div>

                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1.5">
                                Tanggal Lahir <span class="text-red-500">*</span>
                            </label>
                            <input type="date" name="tanggal_lahir" value="{{ old('tanggal_lahir') }}"
                                   max="{{ date('Y-m-d') }}"
                                   class="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-teal-500 @error('tanggal_lahir') border-red-300 bg-red-50 @enderror">
                            @error('tanggal_lahir')
                            <p class="mt-1 text-xs text-red-600">{{ $message }}</p>
                            @enderror
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1.5">
                                Jenis Kelamin <span class="text-red-500">*</span>
                            </label>
                            <select name="jenis_kelamin"
                                    class="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-teal-500 @error('jenis_kelamin') border-red-300 bg-red-50 @enderror">
                                <option value="">-- Pilih --</option>
                                <option value="Laki-laki" {{ old('jenis_kelamin') === 'Laki-laki'  ? 'selected' : '' }}>
                                    Laki-laki
                                </option>
                                <option value="Perempuan" {{ old('jenis_kelamin') === 'Perempuan'  ? 'selected' : '' }}>
                                    Perempuan
                                </option>
                            </select>
                            @error('jenis_kelamin')
                            <p class="mt-1 text-xs text-red-600">{{ $message }}</p>
                            @enderror
                        </div>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1.5">
                            No. HP <span class="text-red-500">*</span>
                        </label>
                        <input type="tel" name="no_hp" value="{{ old('no_hp') }}"
                               placeholder="08xxxxxxxxxx" maxlength="15"
                               class="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-teal-500 @error('no_hp') border-red-300 bg-red-50 @enderror">
                        @error('no_hp')
                        <p class="mt-1 text-xs text-red-600">{{ $message }}</p>
                        @enderror
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1.5">
                            Alamat <span class="text-red-500">*</span>
                        </label>
                        <textarea name="alamat" rows="3" placeholder="Alamat lengkap pasien"
                                  class="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-teal-500 resize-none @error('alamat') border-red-300 bg-red-50 @enderror">{{ old('alamat') }}</textarea>
                        @error('alamat')
                        <p class="mt-1 text-xs text-red-600">{{ $message }}</p>
                        @enderror
                    </div>
                </div>
            </div>

            {{-- Data Kunjungan --}}
            <div class="bg-white border border-gray-200 rounded-xl p-6">
                <p class="text-xs font-medium text-gray-400 uppercase tracking-wide mb-5">
                    <svg class="w-3.5 h-3.5 inline-block mr-1.5 -mt-0.5" fill="none" stroke="currentColor"
                         viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                              d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                    </svg>
                    Data Kunjungan
                </p>

                <div class="space-y-4">
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1.5">
                                Tanggal Kunjungan <span class="text-red-500">*</span>
                            </label>
                            <input type="date" name="tanggal_kunjungan"
                                   value="{{ old('tanggal_kunjungan', date('Y-m-d')) }}"
                                   class="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-teal-500 @error('tanggal_kunjungan') border-red-300 bg-red-50 @enderror">
                            @error('tanggal_kunjungan')
                            <p class="mt-1 text-xs text-red-600">{{ $message }}</p>
                            @enderror
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1.5">
                                Jenis Pembayaran <span class="text-red-500">*</span>
                            </label>
                            <select name="jenis_pembayaran"
                                    class="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-teal-500 @error('jenis_pembayaran') border-red-300 bg-red-50 @enderror">
                                <option value="">-- Pilih --</option>
                                @foreach(['Umum', 'BPJS', 'Asuransi', 'Gratis'] as $p)
                                    <option
                                        value="{{ $p }}" {{ old('jenis_pembayaran') === $p ? 'selected' : '' }}>{{ $p }}</option>
                                @endforeach
                            </select>
                            @error('jenis_pembayaran')
                            <p class="mt-1 text-xs text-red-600">{{ $message }}</p>
                            @enderror
                        </div>
                    </div>

                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1.5">
                                Poli Tujuan <span class="text-red-500">*</span>
                            </label>
                            <select name="poli_tujuan"
                                    class="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-teal-500 @error('poli_tujuan') border-red-300 bg-red-50 @enderror">
                                <option value="">-- Pilih --</option>
                                @foreach(['Poli Umum', 'Poli Gigi', 'Poli Anak', 'Poli Kandungan', 'Poli Mata', 'Poli THT'] as $p)
                                    <option
                                        value="{{ $p }}" {{ old('poli_tujuan') === $p ? 'selected' : '' }}>{{ $p }}</option>
                                @endforeach
                            </select>
                            @error('poli_tujuan')
                            <p class="mt-1 text-xs text-red-600">{{ $message }}</p>
                            @enderror
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1.5">
                                Dokter <span class="text-red-500">*</span>
                            </label>
                            <input type="text" name="dokter" value="{{ old('dokter') }}"
                                   placeholder="Dr.Riza" maxlength="15"
                                   class="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-teal-500 @error('dokter') border-red-300 bg-red-50 @enderror">
                            @error('dokter')
                            <p class="mt-1 text-xs text-red-600">{{ $message }}</p>
                            @enderror
                        </div>
                    </div>
                </div>
            </div>

            <div class="flex items-center justify-end gap-3">
                <a href="{{ route('kunjungan.index') }}"
                   class="text-sm px-4 py-2 border border-gray-200 rounded-lg hover:bg-gray-100 transition">
                    Batal
                </a>
                <button type="submit"
                        class="inline-flex items-center gap-2 bg-teal-600 hover:bg-teal-700 text-white text-sm px-5 py-2 rounded-lg transition">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
                    </svg>
                    Simpan Data
                </button>
            </div>

        </form>
    </div>

@endsection
