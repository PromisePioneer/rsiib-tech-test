@extends('layouts.app')

@section('title', 'Edit Pasien — ' . $pasien->nama_pasien)

@section('content')

    <div class="max-w-3xl">

        <div class="flex items-center gap-3 mb-6">
            <a href="{{ route('kunjungan.index') }}" class="text-gray-400 hover:text-gray-600 transition">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
                </svg>
            </a>
            <div>
                <h1 class="text-xl font-semibold">Edit Pasien</h1>
                <p class="text-sm text-gray-500 mt-0.5">{{ $pasien->nama_pasien }}</p>
            </div>
        </div>

        <form action="{{ route('kunjungan.update', $pasien) }}" method="POST" class="space-y-5">
            @csrf
            @method('PUT')

            {{-- Data Pasien --}}
            <div class="bg-white border border-gray-200 rounded-xl p-6">
                <p class="text-xs font-medium text-gray-400 uppercase tracking-wide mb-5">
                    <svg class="w-3.5 h-3.5 inline-block mr-1.5 -mt-0.5" fill="none" stroke="currentColor"
                         viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                              d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/>
                    </svg>
                    Data Pasien
                </p>

                <div class="space-y-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1.5">
                            Nama Pasien <span class="text-red-500">*</span>
                        </label>
                        <input type="text" name="nama_pasien"
                               value="{{ old('nama_pasien', $pasien->nama_pasien) }}"
                               class="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-teal-500 @error('nama_pasien') border-red-300 bg-red-50 @enderror">
                        @error('nama_pasien')
                        <p class="mt-1 text-xs text-red-600">{{ $message }}</p>
                        @enderror
                    </div>

                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1.5">
                                Tanggal Lahir <span class="text-red-500">*</span>
                            </label>
                            <input type="date" name="tanggal_lahir"
                                   value="{{ old('tanggal_lahir', $pasien->tanggal_lahir->format('Y-m-d')) }}"
                                   max="{{ date('Y-m-d') }}"
                                   class="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-teal-500 @error('tanggal_lahir') border-red-300 bg-red-50 @enderror">
                            @error('tanggal_lahir')
                            <p class="mt-1 text-xs text-red-600">{{ $message }}</p>
                            @enderror
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1.5">
                                Jenis Kelamin <span class="text-red-500">*</span>
                            </label>
                            <select name="jenis_kelamin"
                                    class="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-teal-500 @error('jenis_kelamin') border-red-300 bg-red-50 @enderror">
                                <option
                                    value="Laki-laki" {{ old('jenis_kelamin', $pasien->jenis_kelamin) === 'Laki-laki'  ? 'selected' : '' }}>
                                    Laki-laki
                                </option>
                                <option
                                    value="Perempuan" {{ old('jenis_kelamin', $pasien->jenis_kelamin) === 'Perempuan'  ? 'selected' : '' }}>
                                    Perempuan
                                </option>
                            </select>
                            @error('jenis_kelamin')
                            <p class="mt-1 text-xs text-red-600">{{ $message }}</p>
                            @enderror
                        </div>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1.5">
                            No. HP <span class="text-red-500">*</span>
                        </label>
                        <input type="tel" name="no_hp"
                               value="{{ old('no_hp', $pasien->no_hp) }}"
                               maxlength="15"
                               class="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-teal-500 @error('no_hp') border-red-300 bg-red-50 @enderror">
                        @error('no_hp')
                        <p class="mt-1 text-xs text-red-600">{{ $message }}</p>
                        @enderror
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1.5">
                            Alamat <span class="text-red-500">*</span>
                        </label>
                        <textarea name="alamat" rows="3"
                                  class="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-teal-500 resize-none @error('alamat') border-red-300 bg-red-50 @enderror">{{ old('alamat', $pasien->alamat) }}</textarea>
                        @error('alamat')
                        <p class="mt-1 text-xs text-red-600">{{ $message }}</p>
                        @enderror
                    </div>
                </div>
            </div>

            {{-- Riwayat Kunjungan --}}
            @if($pasien->kunjungan->count())
                <div class="bg-white border border-gray-200 rounded-xl p-6">
                    <p class="text-xs font-medium text-gray-400 uppercase tracking-wide mb-4">
                        <svg class="w-3.5 h-3.5 inline-block mr-1.5 -mt-0.5" fill="none" stroke="currentColor"
                             viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                  d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                        </svg>
                        Riwayat Kunjungan
                    </p>
                    <div class="space-y-2">
                        @foreach($pasien->kunjungan->sortByDesc('tanggal_kunjungan') as $k)
                            <div class="flex items-center justify-between py-2.5 border-b border-gray-50 last:border-0">
                                <div class="flex items-center gap-3">
                                    <div
                                        class="text-xs text-gray-400 w-20">{{ $k->tanggal_kunjungan->format('d M Y') }}</div>
                                    <div
                                        class="text-sm {{ $k->status === 'batal' ? 'line-through text-gray-400' : 'text-gray-700' }}">
                                        {{ $k->poli_tujuan }} — {{ $k->dokter }}
                                    </div>
                                </div>
                                <div class="flex items-center gap-2">
                                    @if($k->status === 'batal')
                                        <span
                                            class="inline-block px-2 py-0.5 rounded-full text-xs bg-red-50 text-red-700">Batal</span>
                                    @else
                                        @php
                                            $colors = ['BPJS'=>'bg-green-50 text-green-700','Umum'=>'bg-gray-100 text-gray-600','Asuransi'=>'bg-amber-50 text-amber-700','Gratis'=>'bg-teal-50 text-teal-700'];
                                            $cls = $colors[$k->jenis_pembayaran] ?? 'bg-gray-100 text-gray-600';
                                        @endphp
                                        <span
                                            class="inline-block px-2 py-0.5 rounded-full text-xs {{ $cls }}">{{ $k->jenis_pembayaran }}</span>
                                        <form action="{{ route('kunjungan.batal', $k) }}" method="POST"
                                              onsubmit="return confirm('Batalkan kunjungan ini?')">
                                            @csrf
                                            @method('PATCH')
                                            <button type="submit"
                                                    class="text-xs text-red-500 hover:text-red-700 border border-red-100 px-2.5 py-1 rounded-lg hover:bg-red-50 transition">
                                                Batal kunjungan
                                            </button>
                                        </form>
                                    @endif
                                </div>
                            </div>
                        @endforeach
                    </div>
                </div>
            @endif

            <div class="flex items-center justify-between">
                <form action="{{ route('kunjungan.destroy', $pasien) }}" method="POST"
                      onsubmit="return confirm('Yakin hapus data pasien {{ $pasien->nama_pasien }}?')">
                    @csrf
                    @method('DELETE')
                    <button type="submit"
                            class="inline-flex items-center gap-1.5 text-sm text-red-600 border border-red-100 px-4 py-2 rounded-lg hover:bg-red-50 transition">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                  d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>
                        </svg>
                        Hapus Pasien
                    </button>
                </form>
                <div class="flex items-center gap-3">
                    <a href="{{ route('kunjungan.index') }}"
                       class="text-sm px-4 py-2 border border-gray-200 rounded-lg hover:bg-gray-100 transition">
                        Batal
                    </a>
                    <button type="submit"
                            class="inline-flex items-center gap-2 bg-teal-600 hover:bg-teal-700 text-white text-sm px-5 py-2 rounded-lg transition">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
                        </svg>
                        Simpan Perubahan
                    </button>
                </div>
            </div>

        </form>
    </div>

@endsection
